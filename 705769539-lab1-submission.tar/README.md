## UID: 705769539
(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

## Pipe Up

This program mimics the pipe "|" operator by using the fork() and pipe() functions

## Building

To build the program, run "make" in the shell

## Running

Ex: $./pipe ls cat ==> running this will run the program ls and feed its input into cat, outputing each file in the current directory on a new line

## Cleaning up

run "make clean" in the shell
