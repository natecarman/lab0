#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  for(int i = argc -1 ; i > 0; i--){
    int fds[2];
    pipe(fds);
    int returncode = fork();
    if(returncode == 0){
      if(i == 1){
	dup2(fds[1],1);
	close(fds[1]);
	close(fds[0]);
	execlp(argv[i],argv[i], NULL);
      }
        dup2(fds[1],1);
        dup2(fds[0],0);
        close(fds[0]);
        close(fds[1]);

    }else if(returncode > 0){
      int pid = returncode;
      int status = 0;
      waitpid(pid, &status, 0);
      if(pid == -1){
        perror("error");
        exit(EXIT_FAILURE);
      }
      if(WIFEXITED(status)){
        if(errno != 0){
          exit(errno);
        }
      }
      dup2(fds[0], 0);
      close(fds[0]);
      close(fds[1]);
      execlp(argv[i],argv[i], NULL);
    }else{
      printf("error");
      perror("fork");
      exit(EXIT_FAILURE);
    }
  }
}
