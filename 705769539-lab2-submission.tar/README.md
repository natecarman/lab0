## UID: 705769539
(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

## Round Robin

This program is a round robin scheduling simulator, it takes in process info from a txt file and ouputs the average wait and response times for the processes

## Building

To build the program, run "make" in the shell

## Running

To run the program type: $./rr (MY_PROCESSES.TXT) (QUANTUM LENGTH). Make sure that the text file you pass into the program has the correct formatting of: #of processes
pid, arrival_time, burst_time (repeat this for each process).

## Cleaning up

run "make clean" in the shell
