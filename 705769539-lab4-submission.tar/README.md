## UID: 705769539

(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

# Hey! I'm Filing Here

This code makes a simple EXT2 file system with root and lost+found directories and hello world file with symlink

## Building

To build the program run the command $make in the shell

## Running

To run, input the command $./ext2-create to compile the filesystem image, then to mount the filesystem, input:
$mkdir mnt
$sudo mount -o loop cs111-base.img mnt
$cd mnt
Then to see if this all worked input $ls -ain to view all the files in the filesystem

## Cleaning up

To unmount the system input:
$cd .. (to exit mnt dir)
$sudo umount mnt (to unmount mnt)
$rmdir mnt
Then to remove all binary files, simply type $make clean into the shell
